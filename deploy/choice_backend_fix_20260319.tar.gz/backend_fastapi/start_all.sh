#!/bin/bash

echo "Starting all FastAPI services..."
echo ""

# Определить внешний IPv4 адрес сервера (для вывода ссылок)
get_server_ip() {
    local ip_addr
    ip_addr=$(hostname -I 2>/dev/null | awk '{print $1}')
    if [[ -n "$ip_addr" ]]; then
        echo "$ip_addr"
        return 0
    fi

    ip_addr=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for (i=1;i<=NF;i++) if ($i=="src") {print $(i+1); exit}}')
    if [[ -n "$ip_addr" ]]; then
        echo "$ip_addr"
        return 0
    fi

    echo "127.0.0.1"
}

SERVER_IP="$(get_server_ip)"

# Выбрать Python (предпочтительно из .venv), чтобы не зависеть от PATH/активации venv
PYTHON_BIN="${PYTHON_BIN:-python3}"
if [[ -x "$(pwd)/.venv/bin/python" ]]; then
    PYTHON_BIN="$(pwd)/.venv/bin/python"
fi

# Проверка, что uvicorn установлен
if ! "$PYTHON_BIN" -c "import uvicorn" >/dev/null 2>&1; then
    echo "ERROR: uvicorn не установлен в окружении ($PYTHON_BIN)."
    echo "Запусти: python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt"
    exit 1
fi

# Функция для запуска сервиса
start_service() {
    local name=$1
    local port=$2
    local module=$3
    local log_name
    log_name=$(printf '%s' "$name" | tr '[:upper:]' '[:lower:]')
    
    echo "Starting $name on port $port..."
    # Важно: запускаем из корня backend_fastapi, чтобы работали импорты пакета `services.*`
    PYTHONPATH="$(pwd)" "$PYTHON_BIN" -m uvicorn "${module}:app" --host 0.0.0.0 --port "$port" --reload > "logs/${log_name}.log" 2>&1 &
    sleep 1
}

# Создать директорию для логов (в backend_fastapi/logs)
mkdir -p logs

# Запуск всех сервисов
start_service "Authentication" 8001 "services.authentication.main"
start_service "Client" 8002 "services.client_service.main"
start_service "Company" 8003 "services.company_service.main"
start_service "Category" 8004 "services.category_service.main"
start_service "Ordering" 8005 "services.ordering.main"
start_service "Chat" 8006 "services.chat.main"
start_service "Review" 8007 "services.review_service.main"
start_service "File" 8008 "services.file_service.main"

echo ""
echo "All services started!"
echo ""
echo "Check Swagger UI:"
echo "- Authentication: http://${SERVER_IP}:8001/docs"
echo "- Client: http://${SERVER_IP}:8002/docs"
echo "- Company: http://${SERVER_IP}:8003/docs"
echo "- Category: http://${SERVER_IP}:8004/docs"
echo "- Ordering: http://${SERVER_IP}:8005/docs"
echo "- Chat: http://${SERVER_IP}:8006/docs"
echo "- Review: http://${SERVER_IP}:8007/docs"
echo "- File: http://${SERVER_IP}:8008/docs"
echo ""
echo "Logs are in logs/ directory"
echo ""
echo "Press Ctrl+C to stop all services"

# Ждать завершения
wait
